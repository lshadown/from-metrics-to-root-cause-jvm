package com.gruzewskidev.api_service;

public class DownstreamException extends RuntimeException {

	public DownstreamException(String message, Throwable cause) {
		super(message, cause);
	}

}
